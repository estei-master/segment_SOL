var classCameraWidget =
[
    [ "CameraWidget", "classCameraWidget.html#a637ffd88fb213dad01dfa7294248029e", null ],
    [ "~CameraWidget", "classCameraWidget.html#a434ed0e3355c13cd4a51eba0dfcfa66a", null ],
    [ "putFrame", "classCameraWidget.html#a9ef3bc90490e18855ac24f29cc5cb20f", null ],
    [ "toPixmap", "classCameraWidget.html#a349b27ddfbcd67ae055f56e51ffe3e44", null ],
    [ "m_image", "classCameraWidget.html#a953550f36cf3dd234dd33e36f0e85e95", null ],
    [ "m_imageLabel", "classCameraWidget.html#aca76b8be07d57c2d715a685768dfcbe6", null ],
    [ "m_layout", "classCameraWidget.html#a22be3fef82e8e5c1e125b280ec1434df", null ]
];