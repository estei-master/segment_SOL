var searchData=
[
  ['tramdataid',['tramDataId',['../typdefUart_8h.html#a7fdf1e7bfbebe0c7a2eb84a10e069632',1,'typdefUart.h']]]
];
