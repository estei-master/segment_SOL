var annotated =
[
    [ "Ui", "namespaceUi.html", null ],
    [ "battery", "classbattery.html", "classbattery" ],
    [ "CameraWidget", "classCameraWidget.html", "classCameraWidget" ],
    [ "droneBatteryData", "structdroneBatteryData.html", "structdroneBatteryData" ],
    [ "droneConfig", "structdroneConfig.html", "structdroneConfig" ],
    [ "droneGPSData", "structdroneGPSData.html", "structdroneGPSData" ],
    [ "droneIMUData", "structdroneIMUData.html", "structdroneIMUData" ],
    [ "droneState", "structdroneState.html", "structdroneState" ],
    [ "droneTelemeterData", "structdroneTelemeterData.html", "structdroneTelemeterData" ],
    [ "flightCommand", "structflightCommand.html", "structflightCommand" ],
    [ "LightMaps", "classLightMaps.html", "classLightMaps" ],
    [ "MainWindow", "classMainWindow.html", "classMainWindow" ],
    [ "MyDisplay", "classMyDisplay.html", "classMyDisplay" ],
    [ "Nunchuck", "classNunchuck.html", "classNunchuck" ],
    [ "qAttitudeIndicator", "classqAttitudeIndicator.html", "classqAttitudeIndicator" ],
    [ "QBase", "classQBase.html", "classQBase" ],
    [ "SlippyMap", "classSlippyMap.html", "classSlippyMap" ],
    [ "tramZigbee", "structtramZigbee.html", "structtramZigbee" ],
    [ "Uart", "classUart.html", "classUart" ],
    [ "ZigBee", "classZigBee.html", "classZigBee" ]
];