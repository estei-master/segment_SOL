var hierarchy =
[
    [ "droneBatteryData", "structdroneBatteryData.html", null ],
    [ "droneConfig", "structdroneConfig.html", null ],
    [ "droneGPSData", "structdroneGPSData.html", null ],
    [ "droneIMUData", "structdroneIMUData.html", null ],
    [ "droneState", "structdroneState.html", null ],
    [ "droneTelemeterData", "structdroneTelemeterData.html", null ],
    [ "flightCommand", "structflightCommand.html", null ],
    [ "MyDisplay", "classMyDisplay.html", null ],
    [ "Nunchuck", "classNunchuck.html", null ],
    [ "QMainWindow", null, [
      [ "battery", "classbattery.html", null ],
      [ "MainWindow", "classMainWindow.html", null ]
    ] ],
    [ "QObject", null, [
      [ "SlippyMap", "classSlippyMap.html", null ]
    ] ],
    [ "QThread", null, [
      [ "QBase", "classQBase.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "CameraWidget", "classCameraWidget.html", null ],
      [ "LightMaps", "classLightMaps.html", null ],
      [ "qAttitudeIndicator", "classqAttitudeIndicator.html", null ]
    ] ],
    [ "tramZigbee", "structtramZigbee.html", null ],
    [ "Uart", "classUart.html", [
      [ "ZigBee", "classZigBee.html", null ]
    ] ]
];