var classbattery =
[
    [ "battery", "classbattery.html#a5fa1ba3fd447e78847e63f5733e157af", null ],
    [ "timerEvent", "classbattery.html#a22c4b7b9932a588d61fde097aa7a91a5", null ],
    [ "progressBar", "classbattery.html#af0da6fea5bb4d46f1e4bd9b3abe970ed", null ]
];