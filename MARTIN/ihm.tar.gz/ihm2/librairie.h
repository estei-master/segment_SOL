#ifndef LIBRAIRIE_H
#define LUBRAIRIE_H
#include <stdio.h>
#include <iostream>
#include </usr/local/include/opencv2/core/core.hpp>
#include </usr/local/include/opencv2/features2d/features2d.hpp>
#include </usr/local/include/opencv2/highgui/highgui.hpp>
#include </usr/local/include/opencv2/calib3d/calib3d.hpp>
#include </usr/local/include/opencv2/imgproc/imgproc_c.h>
#include </usr/local/include/opencv2/opencv.hpp>
//#include <opencv2\gpu\gpu.hpp>
#include </usr/local/include/opencv2/contrib/contrib.hpp>
#include </usr/local/include/opencv2/objdetect/objdetect.hpp>
#include <thread>
#include <vector>

using namespace cv;
using namespace std;
//using namespace cv::gpu;


#endif
