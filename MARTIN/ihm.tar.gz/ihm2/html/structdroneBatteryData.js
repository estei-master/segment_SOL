var structdroneBatteryData =
[
    [ "ulPowerLvl", "structdroneBatteryData.html#a789c02e04e8c2e46989309ff33c44b1d", null ],
    [ "xUpdateTime", "structdroneBatteryData.html#a52ebc5b82ebb0220cff03229eb9c660f", null ]
];