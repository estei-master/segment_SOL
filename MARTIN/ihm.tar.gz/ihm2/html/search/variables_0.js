var searchData=
[
  ['align',['align',['../mainwindow_8ui.html#ab28bdaf6ad2b6aba883d92e474f75867',1,'mainwindow.ui']]]
];
