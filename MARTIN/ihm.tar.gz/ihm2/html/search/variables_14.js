var searchData=
[
  ['xbatterymonitoringperiod',['xBatteryMonitoringPeriod',['../structdroneConfig.html#afa883d29d2c43da22c11352af00ffb7b',1,'droneConfig']]],
  ['xbatterytimeout',['xBatteryTimeout',['../structdroneConfig.html#a30a59cf24e01d514b6d72c86deb1f02e',1,'droneConfig']]],
  ['xdetectobstacleperiod',['xDetectObstaclePeriod',['../structdroneConfig.html#ac536a237bbb15769d731ec98495d7d97',1,'droneConfig']]],
  ['xflightctrlperiod',['xFlightCtrlPeriod',['../structdroneConfig.html#a92f8e6403d9ca068830a44280239e551',1,'droneConfig']]],
  ['xgpsreceiveperiod',['xGPSReceivePeriod',['../structdroneConfig.html#ae0b978b5906545132a1a1a37c3ca4907',1,'droneConfig']]],
  ['xgpstimeout',['xGPSTimeout',['../structdroneConfig.html#ae272c4dd5a556fe40d2ea3105bf0aa96',1,'droneConfig']]],
  ['ximudatatimeout',['xIMUDataTimeout',['../structdroneConfig.html#a9abfb72bb174ea001aa9cbe0e196fac7',1,'droneConfig']]],
  ['xtelemetertimeout',['xTelemeterTimeout',['../structdroneConfig.html#aa191e8867f3a6277d18a0f4379affb1b',1,'droneConfig']]],
  ['xupdatetime',['xUpdateTime',['../structdroneIMUData.html#a0ae68e4b692508cf64953adcb12443e1',1,'droneIMUData::xUpdateTime()'],['../structdroneGPSData.html#a70d6916fb0e0d02ee97ee4208cafbbed',1,'droneGPSData::xUpdateTime()'],['../structdroneTelemeterData.html#ae1463929a7d9d3b5ef29137e92472f31',1,'droneTelemeterData::xUpdateTime()'],['../structdroneBatteryData.html#a52ebc5b82ebb0220cff03229eb9c660f',1,'droneBatteryData::xUpdateTime()']]],
  ['xvideotoggleperiod',['xVideoTogglePeriod',['../structdroneConfig.html#a7035d86cd38b594b1dbb98a80620ed22',1,'droneConfig']]],
  ['xzigbeecmdtimeout',['xZigbeeCmdTimeout',['../structdroneConfig.html#a2eee39829fa6406904f2853658554814',1,'droneConfig']]],
  ['xzigbeereceiveperiod',['xZigbeeReceivePeriod',['../structdroneConfig.html#a8f16de66ac71b922d151ea165b9f4871',1,'droneConfig']]],
  ['xzigbeereceivetimeout',['xZigbeeReceiveTimeout',['../structdroneConfig.html#a5708172eb0cdfd665ee9ba776168faa1',1,'droneConfig']]]
];
