var mydisplay_8cpp =
[
    [ "inversion", "mydisplay_8cpp.html#a040fad353c8bfac3cd8329eb5ea18910", null ],
    [ "threshold_select", "mydisplay_8cpp.html#ae457e5865ed4e7b5a35200fd4b3b8f47", null ]
];