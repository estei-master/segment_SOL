var qattitudeindicator_8cpp =
[
    [ "defaultsRollRotate", "qattitudeindicator_8cpp.html#a2f4f279d4d5470569f9b4d6db0e913c3", null ],
    [ "defaultsTypePitch", "qattitudeindicator_8cpp.html#aeb622d2485fb495e7b9864ca595af136", null ],
    [ "defaultsTypeRoll", "qattitudeindicator_8cpp.html#a3e866b9c9b8bde50fd68030b49604a15", null ]
];