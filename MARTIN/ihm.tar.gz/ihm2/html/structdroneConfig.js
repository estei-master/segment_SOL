var structdroneConfig =
[
    [ "ulCritBatteryLvl", "structdroneConfig.html#a4ec612c83c80eba7815c541307c9f619", null ],
    [ "ulCritObstacleDist", "structdroneConfig.html#a39b4ebfe2fad46f568b7a2953fc8f46d", null ],
    [ "ulCritZigbeeSignalLvl", "structdroneConfig.html#ace08c1c7161f782950192970d7a19d75", null ],
    [ "ulMaxAngle", "structdroneConfig.html#a0f6ba8c7c50c247ef54fa48e0f7ef729", null ],
    [ "ulMinAltitude", "structdroneConfig.html#a93de26859c52f79b9801cf74e1e37add", null ],
    [ "ulRefAltitude", "structdroneConfig.html#a7d7f05ea8f93c206ce1a8a2fa868c587", null ],
    [ "ulTakeoffAltitude", "structdroneConfig.html#a732c5a9d1af9eec7412c8a282109728a", null ],
    [ "xBatteryMonitoringPeriod", "structdroneConfig.html#afa883d29d2c43da22c11352af00ffb7b", null ],
    [ "xBatteryTimeout", "structdroneConfig.html#a30a59cf24e01d514b6d72c86deb1f02e", null ],
    [ "xDetectObstaclePeriod", "structdroneConfig.html#ac536a237bbb15769d731ec98495d7d97", null ],
    [ "xFlightCtrlPeriod", "structdroneConfig.html#a92f8e6403d9ca068830a44280239e551", null ],
    [ "xGPSReceivePeriod", "structdroneConfig.html#ae0b978b5906545132a1a1a37c3ca4907", null ],
    [ "xGPSTimeout", "structdroneConfig.html#ae272c4dd5a556fe40d2ea3105bf0aa96", null ],
    [ "xIMUDataTimeout", "structdroneConfig.html#a9abfb72bb174ea001aa9cbe0e196fac7", null ],
    [ "xTelemeterTimeout", "structdroneConfig.html#aa191e8867f3a6277d18a0f4379affb1b", null ],
    [ "xVideoTogglePeriod", "structdroneConfig.html#a7035d86cd38b594b1dbb98a80620ed22", null ],
    [ "xZigbeeCmdTimeout", "structdroneConfig.html#a2eee39829fa6406904f2853658554814", null ],
    [ "xZigbeeReceivePeriod", "structdroneConfig.html#a8f16de66ac71b922d151ea165b9f4871", null ],
    [ "xZigbeeReceiveTimeout", "structdroneConfig.html#a5708172eb0cdfd665ee9ba776168faa1", null ]
];