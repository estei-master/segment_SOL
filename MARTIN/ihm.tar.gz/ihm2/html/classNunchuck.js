var classNunchuck =
[
    [ "Nunchuck", "classNunchuck.html#a655b8b1dcb8afcb60b44fcd5ab328407", null ],
    [ "~Nunchuck", "classNunchuck.html#a2ff51de933f8099585f36eee2f280b38", null ],
    [ "DecodeBufferIn", "classNunchuck.html#aac4e5f6da04ee3fb6beada59aefd1612", null ],
    [ "Initialize", "classNunchuck.html#aabc3105bbe185edb4521506e5da3dc48", null ],
    [ "ReadCommand", "classNunchuck.html#ade6607a55fda6ae67c90d3d1ee7ce56b", null ],
    [ "bButtonC", "classNunchuck.html#a1d5cac3b603b3060984e3184d795561d", null ],
    [ "bButtonZ", "classNunchuck.html#a0db1f3d2f58fafda23a5af3936c12598", null ],
    [ "bInitialize", "classNunchuck.html#a3ecbcb3a01a247605b4f0a37b579581d", null ],
    [ "cBufferIn", "classNunchuck.html#a1bd7122f88582d12ab2ac5d3c8c7b8f8", null ],
    [ "cBufferOut", "classNunchuck.html#a4f2eea10fb4eba245c24168ce00429f8", null ],
    [ "cJoystickX", "classNunchuck.html#ad9467642b97b8b008ddd137d273a22f8", null ],
    [ "cJoystickY", "classNunchuck.html#aaf0f299016f5acf686f716518a7ce567", null ],
    [ "fDevice", "classNunchuck.html#a61f4874769103ba04e13f75a08442f8e", null ],
    [ "iData", "classNunchuck.html#a6bf3cbe405e9611658f1a6bbc1cd56b4", null ],
    [ "iSizeBuffer", "classNunchuck.html#a671e2732508cdd56e51898b79e58d455", null ],
    [ "iValueJoystickX", "classNunchuck.html#a931870243c74e9df416639c53670b234", null ],
    [ "iValueJoystickY", "classNunchuck.html#a0e084b1760acfc06305bbb339e3c8232", null ]
];