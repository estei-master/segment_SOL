var structdroneTelemeterData =
[
    [ "xUpdateTime", "structdroneTelemeterData.html#ae1463929a7d9d3b5ef29137e92472f31", null ]
];