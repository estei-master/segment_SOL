var searchData=
[
  ['history_5fdest_5fh',['HISTORY_DEST_H',['../uart_8h.html#a2d0c6f9659fde77efee0b205d121ff46',1,'uart.h']]],
  ['history_5fdest_5fl',['HISTORY_DEST_L',['../uart_8h.html#a05660c40ae41611e14b7aea03ea994be',1,'uart.h']]],
  ['hold_5ftime',['HOLD_TIME',['../lightmaps_8cpp.html#a3f171629948a6f7ad5c9e9a4d9f1366c',1,'lightmaps.cpp']]]
];
