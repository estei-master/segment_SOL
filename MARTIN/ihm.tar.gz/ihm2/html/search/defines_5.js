var searchData=
[
  ['m_5fpi',['M_PI',['../lightmaps_8cpp.html#ae71449b1cc6e6250b91f539153a7a0d3',1,'M_PI():&#160;lightmaps.cpp'],['../slippymap_8cpp.html#ae71449b1cc6e6250b91f539153a7a0d3',1,'M_PI():&#160;slippymap.cpp']]],
  ['max_5fmagnifier',['MAX_MAGNIFIER',['../lightmaps_8cpp.html#a51ac6ea721e00a4f2396493f9517b9e5',1,'lightmaps.cpp']]]
];
