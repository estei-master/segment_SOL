var mainwindow_8ui =
[
    [ "align", "mainwindow_8ui.html#ab28bdaf6ad2b6aba883d92e474f75867", null ],
    [ "gt", "mainwindow_8ui.html#acc2b3ab3dd842d17613f7a6cbf7f275d", null ],
    [ "lt", "mainwindow_8ui.html#a857c8c8ca640fb2283d751a715bd1ee9", null ],
    [ "quot", "mainwindow_8ui.html#a6ac641f7a2ac50c1fa0b167e88309133", null ]
];