var lightmaps_8cpp =
[
    [ "HOLD_TIME", "lightmaps_8cpp.html#a3f171629948a6f7ad5c9e9a4d9f1366c", null ],
    [ "M_PI", "lightmaps_8cpp.html#ae71449b1cc6e6250b91f539153a7a0d3", null ],
    [ "MAX_MAGNIFIER", "lightmaps_8cpp.html#a51ac6ea721e00a4f2396493f9517b9e5", null ]
];