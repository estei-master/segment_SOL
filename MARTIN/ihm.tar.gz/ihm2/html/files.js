var files =
[
    [ "battery.cpp", "battery_8cpp.html", null ],
    [ "battery.h", "battery_8h.html", [
      [ "battery", "classbattery.html", "classbattery" ]
    ] ],
    [ "camerawidget.cpp", "camerawidget_8cpp.html", null ],
    [ "camerawidget.h", "camerawidget_8h.html", [
      [ "CameraWidget", "classCameraWidget.html", "classCameraWidget" ]
    ] ],
    [ "librairie.h", "librairie_8h.html", "librairie_8h" ],
    [ "lightmaps.cpp", "lightmaps_8cpp.html", "lightmaps_8cpp" ],
    [ "lightmaps.h", "lightmaps_8h.html", [
      [ "LightMaps", "classLightMaps.html", "classLightMaps" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", "mainwindow_8h" ],
    [ "mainwindow.ui", "mainwindow_8ui.html", "mainwindow_8ui" ],
    [ "mydisplay.cpp", "mydisplay_8cpp.html", "mydisplay_8cpp" ],
    [ "mydisplay.h", "mydisplay_8h.html", "mydisplay_8h" ],
    [ "nunchuck.cpp", "nunchuck_8cpp.html", null ],
    [ "nunchuck.h", "nunchuck_8h.html", "nunchuck_8h" ],
    [ "qattitudeindicator.cpp", "qattitudeindicator_8cpp.html", "qattitudeindicator_8cpp" ],
    [ "qattitudeindicator.h", "qattitudeindicator_8h.html", "qattitudeindicator_8h" ],
    [ "qbase.cpp", "qbase_8cpp.html", null ],
    [ "qbase.h", "qbase_8h.html", [
      [ "QBase", "classQBase.html", "classQBase" ]
    ] ],
    [ "slippymap.cpp", "slippymap_8cpp.html", "slippymap_8cpp" ],
    [ "slippymap.h", "slippymap_8h.html", [
      [ "SlippyMap", "classSlippyMap.html", "classSlippyMap" ]
    ] ],
    [ "typdefUart.h", "typdefUart_8h.html", "typdefUart_8h" ],
    [ "uart.cpp", "uart_8cpp.html", null ],
    [ "uart.h", "uart_8h.html", "uart_8h" ],
    [ "zigbee.cpp", "zigbee_8cpp.html", null ],
    [ "zigbee.h", "zigbee_8h.html", [
      [ "ZigBee", "classZigBee.html", "classZigBee" ]
    ] ]
];