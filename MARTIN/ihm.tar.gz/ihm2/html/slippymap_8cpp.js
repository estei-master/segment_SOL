var slippymap_8cpp =
[
    [ "M_PI", "slippymap_8cpp.html#ae71449b1cc6e6250b91f539153a7a0d3", null ],
    [ "latitudeFromTile", "slippymap_8cpp.html#adbe934a4ade6aa7f2e0d82a4fe6e71e3", null ],
    [ "longitudeFromTile", "slippymap_8cpp.html#abfafaf71741cb91b95caa7218bf2993e", null ],
    [ "qHash", "slippymap_8cpp.html#acc2ff595306dab2c33e934d7e24edac3", null ],
    [ "tileForCoordinate", "slippymap_8cpp.html#a7b006b28fd0e4ace99c58e6162b501c9", null ],
    [ "tdim", "slippymap_8cpp.html#a8ce10e914ae6c794640aeae2e2781d83", null ]
];