var structtramZigbee =
[
    [ "Data", "structtramZigbee.html#a3871224e0e052d996b31a4f1d4df51f2", null ],
    [ "lengthData", "structtramZigbee.html#a688bc48e9e6da34837d4636d5e60b849", null ]
];