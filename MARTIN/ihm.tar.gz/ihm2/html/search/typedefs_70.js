var searchData=
[
  ['portticktype',['portTickType',['../typdefUart_8h.html#ae9fa5e001303f1be1c0294f26cde8caf',1,'typdefUart.h']]]
];
