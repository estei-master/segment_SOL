var qth__base_8h =
[
    [ "QTh_Base", "classQTh__Base.html", "classQTh__Base" ],
    [ "QTHREAD_COMUNICATION", "qth__base_8h.html#a252b70ead8dbf51b155ecb9f0c7fd15a", null ],
    [ "QTHREAD_HORIZON", "qth__base_8h.html#a2f3670a7586687feccfde021b896c2b8", null ]
];