var searchData=
[
  ['gt',['gt',['../mainwindow_8ui.html#acc2b3ab3dd842d17613f7a6cbf7f275d',1,'mainwindow.ui']]]
];
